from flask import Flask, request, jsonify, render_template_string

app = Flask(__name__)

# Sample flight route data based on your document
ROUTES = {
    ("JFK", "LHR"): "3h 50m",
    ("MIA", "CDG"): "4h 20m",
    ("LAX", "HND"): "5h 20m",
    ("ORD", "FCO"): "4h 50m",
    ("SEA", "PEK"): "5h 00m"
}

# Pricing and capacity
PRICING = {
    "Gold": {"min": 12000, "max": 15000, "capacity": 200},
    "Silver": {"min": 1500, "max": 2000, "capacity": 600},
    "Platinum": {"min": 0, "max": 0, "capacity": "Request Only"}
}

@app.route('/api/book-flight', methods=['POST'])
def book_flight():
    data = request.json
    route_key = (data['from'], data['to'])
    flight_class = data['class']
    passengers = int(data['passengers'])

    if flight_class == "Platinum":
        return jsonify({
            "message": "Platinum booking must be made via phone. Please call 1-800-TWIN-AIR."
        })

    if route_key not in ROUTES:
        return jsonify({"message": "Sorry, this route is not available."}), 400

    if passengers > PRICING[flight_class]["capacity"]:
        return jsonify({"message": f"Too many passengers for {flight_class} class. Max is {PRICING[flight_class]['capacity']}."}), 400

    cost_range = PRICING[flight_class]
    message = (
        f"Your {flight_class} class flight from {data['from']} to {data['to']} "
        f"on {data['date']} for {passengers} passenger(s) is confirmed!\n"
        f"Estimated duration: {ROUTES[route_key]}.\n"
        f"Estimated total cost: ${cost_range['min'] * passengers:,} - ${cost_range['max'] * passengers:,}."
    )

    return jsonify({"message": message})

if __name__ == '__main__':
    app.run(debug=True)
